<?php
    $plugin->version = 2013012300;    // YYYYMMDDHH (year, month, day, 24-hr time)    
	$plugin->release = 2012012300;    // YYYYMMDDHH (This is the release version)
	$plugin->requires = 2011120500;   // YYYYMMDDHH (This is the moodle release version)
    $plugin->component = 'auth_ldapcapture';
	$plugin->maturity = MATURITY_RC;
    
?>
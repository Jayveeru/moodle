<?php

// legacy support - wraps new aes encryption library into old encryption class

include_once('aes_encryption.php');

class encryption {
    public static function encrypt ($password, $key){
        return (LDC_AesCtr::encrypt($password, $key, 256));
    }
    public static function decrypt ($password, $key){
        return (LDC_AesCtr::decrypt($password, $key, 256));
    }
}
?>

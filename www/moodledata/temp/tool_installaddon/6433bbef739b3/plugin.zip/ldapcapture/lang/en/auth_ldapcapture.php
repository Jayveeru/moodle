<?php

// ldap capture plugin (captures user login with encrypted password instead of hashed password)
$string['auth_ldapcapturetitle']='LDAP Capture';
$string['pluginname']='LDAP Capture';
$string['auth_ldapcapturedescription']='<p>This plugin is a wrapper for the ldap plugin. It enables you to capture (to the user session variable) usernames and passwords on login. Passwords are encrypted for security using AES encryption.<p>';
$string['auth_ldapdescription']=$string['auth_ldapcapturedescription'];
$string['auth_ldap_mcryptkey']='Encryption Key';

?>
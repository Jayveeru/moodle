<?php
/**
 * @author Guy Thomas
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package moodle ldapcapture
 *
 * Authentication Plugin: LDAP Capture Authentication
 *
 * Uses the standard LDAP plugin to authenticate but then stores an encrypted version of the user password
 * in the global $SESSION object ($SESSION->epassword)
 * This enables you to then pass user credentials on to other systems from moodle (e.g. windows share web client)
 *
 *
 */

if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}

require_once('aes_encryption.php');
require_once($CFG->libdir.'/authlib.php');
require_once($CFG->libdir.'/ldaplib.php');
require_once($CFG->dirroot.'/auth/ldap/auth.php');

/**
 * LDAP capture authentication plugin.
 */
class auth_plugin_ldapcapture extends auth_plugin_ldap {

    var $version;

    /**
     * Constructor.
     */
    function auth_plugin_ldapcapture() {      	    
        // call ldap constructor
        parent::auth_plugin_ldap();
        
        // set auth type
        $this->authtype = 'ldapcapture';    
    }

     
    
    /**
    * Called on successful authentication
    */
    function user_authenticated_hook(&$user, $username, $password) {
        
        global $SESSION;
        
        // login is ok so capture password
        
        // Setup encryption key md5 crypt key - have had to remove session key as part of crypt key as it seemed to be causing issues with Moodle 2
        $key=md5($this->config->mcryptkey);
        $epassword=LDC_AesCtr::encrypt($password, $key, 256);

        // the following line is an example - its showing you how to decrypt the encrypted password
        // $dpassword=LDC_AesCtr::decrypt($epassword, $key, 256); // e.g. how to decrypt

        $SESSION->epassword=$epassword;  // set encrypted password property for user
        
    }
    
    
    /**
     * Prints a form for configuring this authentication plugin.
     *
     * This function is called from admin/auth.php, and outputs a full page with
     * a form for configuring this plugin.
     *
     * @param array $page An object containing all the data for this page.
     */    
    function config_form($config, $err, $user_fields) {      
	
        // GT MOD - 2008/09/02 - bug fix - latest config was not being shown
        if ($config!==null && !empty($config) && isset($config->host_url)){
            $this->config=$config;
        } else {
            if (isset($this->config->host_url)){
                $config=$this->config;
            } else {
                $config=get_config('auth/ldap');
                $this->config=$config;
            }
        }
        // END GT MOD - 2008/09/02
        
        include 'config.html';    
        $this->authtype = 'ldap';		
        parent::config_form($this->config, $err, $user_fields);
        $this->authtype = 'ldapcapture';  
    }

    
    /**
     * Processes and stores configuration data for this authentication plugin.
     */
    function process_config($config) {
                   
        // set to defaults if undefined
        if (!isset($config->mcryptkey)) {$config->mcryptkey='';}

        // if full config not available then get it and just add in the mcryptkey value
        if (!isset($config->host_url)){
            $mcryptkey=$config->mcryptkey;
            $config=get_config('auth/ldap');
            $config->mcryptkey=$mcryptkey;
        }

        // save ldap auth capture settings
        set_config('mcryptkey', $config->mcryptkey, 'auth/ldap');
       
        // get user mappings and save to ldap config (they will also get saved to ldapcapture config)
        foreach ($this->userfields as $field) {
            $proparr=array('map','updatelocal', 'updateremote', 'lock');
            foreach ($proparr as $prop){
                $propname='field_'.$prop.'_'.$field;
                set_config($propname, $config->{"lockconfig_$propname"}, 'auth/ldap');
            }
        }

        // save ldap auth settings		
        return(parent::process_config($config));
    }    
    
 
       
    
}

?>